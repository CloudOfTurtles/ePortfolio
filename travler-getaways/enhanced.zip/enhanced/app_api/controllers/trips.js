const mongoose = require('mongoose');
const Trip = require('../models/travlr'); // Register model
const Model = mongoose.model('trips');

// Utility to send a JSON response with status
const sendJsonResponse = (res, status, content) => {
  res.status(status).json(content);
};

// Centralized handler for Mongoose errors
const handleMongooseError = (err, res, defaultMessage) => {
  console.error(defaultMessage, err);

  // Validation errors
  if (err.name === 'ValidationError') {
    const errors = Object.keys(err.errors).map(field => ({
      field,
      message: err.errors[field].message
    }));

    return sendJsonResponse(res, 400, {
      message: 'Validation failed',
      errors
    });
  }

  // Fallback: generic server error
  return sendJsonResponse(res, 500, {
    message: defaultMessage || 'Internal server error'
  });
};

// GET /trips - list all trips
// Regardless of outcome, response includes HTTP status + JSON
const tripsList = async (req, res) => {
  try {
    const trips = await Model.find({}).exec();
    // Success: return list
    return sendJsonResponse(res, 200, trips);
  } catch (err) {
    return handleMongooseError(err, res, 'Error retrieving trips list');
  }
};

// GET /trips/:tripCode - get a single trip by code
const tripsFindByCode = async (req, res) => {
  const tripCode = req.params.tripCode;

  if (!tripCode) {
    return sendJsonResponse(res, 400, {
      message: 'tripCode parameter is required'
    });
  }

  try {
    const trip = await Model.findOne({ code: tripCode }).exec();

    if (!trip) {
      return sendJsonResponse(res, 404, {
        message: `Trip with code ${tripCode} not found`
      });
    }

    return sendJsonResponse(res, 200, trip);
  } catch (err) {
    return handleMongooseError(err, res, `Error retrieving trip ${tripCode}`);
  }
};

// POST /trips - add a new trip
const tripsAddTrip = async (req, res) => {
  try {
    const trip = await Model.create({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    });

    // Created
    return sendJsonResponse(res, 201, trip);
  } catch (err) {
    return handleMongooseError(err, res, 'Error creating trip');
  }
};

// PUT /trips/:tripCode - update an existing trip by code
const tripsUpdateTrip = async (req, res) => {
  const tripCode = req.params.tripCode;

  if (!tripCode) {
    return sendJsonResponse(res, 400, {
      message: 'tripCode parameter is required'
    });
  }

  try {
    const trip = await Model.findOne({ code: tripCode }).exec();

    if (!trip) {
      return sendJsonResponse(res, 404, {
        message: `Trip with code ${tripCode} not found`
      });
    }

    const updatableFields = [
      'code',
      'name',
      'length',
      'start',
      'resort',
      'perPerson',
      'image',
      'description'
    ];

    updatableFields.forEach(field => {
      if (Object.prototype.hasOwnProperty.call(req.body, field)) {
        trip[field] = req.body[field];
      }
    });

    const updatedTrip = await trip.save();
    return sendJsonResponse(res, 200, updatedTrip);
  } catch (err) {
    return handleMongooseError(err, res, `Error updating trip ${tripCode}`);
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip
};

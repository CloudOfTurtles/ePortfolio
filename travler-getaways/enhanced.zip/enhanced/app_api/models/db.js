// Bring in the Mongoose module
const Mongoose = require("mongoose");
require("dotenv").config();

// Support full MongoDB connection strings via MONGODB_URI
// Fall back to host + default db name if not provided
const DB_HOST = process.env.DDB_HOST || "127.0.0.1";
const DB_NAME = "travlr";
const LOCAL_URI = `mongodb://${DB_HOST}:27017/${DB_NAME}`;
const DB_URI = process.env.MONGODB_URI || LOCAL_URI;

// Connect to the DB with standard options and catch initial errors
Mongoose.connect(DB_URI, {
  useUnifiedTopology: true,
  useNewUrlParser: true,
})
  .then(() => {
    console.log(`Connected to MongoDB at ${DB_URI}`);
  })
  .catch((err) => {
    console.error("Initial MongoDB connection error:", err);
  });

// Watch the connection for runtime errors
Mongoose.connection.on("error", (err) => {
  console.error("MongoDB connection error:", err);
});

// Graceful shutdown helper
const gracefulShutdown = (msg) => {
  Mongoose.connection.close(() => {
    console.log(`MongoDB disconnected through ${msg}`);
  });
};

// For Nodemon restarts
process.once("SIGUSR2", () => {
  gracefulShutdown("nodemon restart");
  process.kill(process.pid, "SIGUSR2");
});

// For app termination (Ctrl+C)
process.on("SIGINT", () => {
  gracefulShutdown("app termination");
  process.exit(0);
});

// For Heroku / container shutdown
process.on("SIGTERM", () => {
  gracefulShutdown("Heroku shutdown");
  process.exit(0);
});

module.exports = Mongoose;

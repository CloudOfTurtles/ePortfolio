import { Injectable, Provider } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HTTP_INTERCEPTORS,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Authentication } from '../services/authentication';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  constructor(private authentication: Authentication) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // Detect login/register so we DON'T attach a token to those calls
    let isAuthAPI = false;
    try {
      const url = new URL(request.url, window.location.origin);
      isAuthAPI = /\/(login|register)\b/.test(url.pathname);
    } catch {
      // Fallback if URL constructor fails (e.g., unusual relative URL)
      isAuthAPI = /\/(login|register)\b/.test(request.url);
    }

    const token = this.authentication.getToken?.() ?? '';

    if (token && !isAuthAPI) {
      const authReq = request.clone({
        setHeaders: { Authorization: `Bearer ${token}` }
      });
      return next.handle(authReq);
    }

    return next.handle(request);
  }
}

// Provider to register in app.config.ts
export const authInterceptProvider: Provider = {
  provide: HTTP_INTERCEPTORS,
  useClass: JwtInterceptor,
  multi: true
};

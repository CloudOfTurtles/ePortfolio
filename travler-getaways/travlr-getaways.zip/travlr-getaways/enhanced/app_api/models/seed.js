// Bring in the DB connection and the Trip schema
const Mongoose = require('./db');
const Trip = require('./travlr');

// Read seed data from json file
const fs = require('fs');
const trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));

// Delete any existing records, then insert seed data
const seedDB = async () => {
  try {
    const deleteResult = await Trip.deleteMany({});
    console.log(`Deleted ${deleteResult.deletedCount} existing trip(s).`);

    const insertResult = await Trip.insertMany(trips);
    console.log(`Inserted ${insertResult.length} trip(s) from seed data.`);
  } catch (err) {
    console.error('Error during database seeding:', err);
    // Re-throw so the outer handler can deal with it
    throw err;
  }
};

// Close the MongoDB connection and exit
seedDB()
  .then(async () => {
    try {
      await Mongoose.connection.close();
      console.log('MongoDB connection closed after successful seeding.');
    } catch (closeErr) {
      console.error('Error closing MongoDB connection after success:', closeErr);
    }
    process.exit(0);
  })
  .catch(async (err) => {
    console.error('Seeding failed. Closing MongoDB connection.', err);
    try {
      await Mongoose.connection.close();
    } catch (closeErr) {
      console.error('Error closing MongoDB connection after failure:', closeErr);
    }
    process.exit(1);
  });
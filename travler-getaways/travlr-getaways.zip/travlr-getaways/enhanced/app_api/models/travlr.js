const mongoose = require('mongoose');

// Define the trip schema
const tripSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: [true, 'Trip code is required'],
      trim: true,
      index: true
    },
    name: {
      type: String,
      required: [true, 'Trip name is required'],
      trim: true,
      minlength: [3, 'Trip name must be at least 3 characters long'],
      index: true
    },
    length: {
      type: String,
      required: [true, 'Trip length is required'],
      trim: true,
      minlength: [3, 'Trip length description must be at least 3 characters']
    },
    start: {
      type: Date,
      required: [true, 'Start date is required']
    },
    resort: {
      type: String,
      required: [true, 'Resort is required'],
      trim: true
    },
    perPerson: {
      type: String,
      required: [true, 'Per-person price is required'],
      trim: true,
      validate: {
        validator: value => /^\d+(\.\d{2})?$/.test(value),
        message: props =>
          `${props.value} is not a valid price format (expected something like 799.00)`
      }
    },
    image: {
      type: String,
      required: [true, 'Image filename is required'],
      trim: true
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      trim: true,
      maxlength: [4000, 'Description cannot exceed 4000 characters']
    }
  },
  {
    // Adds createdAt / updatedAt fields automatically
    timestamps: true
  }
);

// Extra index to support queries by resort & start date
tripSchema.index({ resort: 1, start: 1 });

// Clean up JSON output
tripSchema.set('toJSON', {
  virtuals: true,
  versionKey: false,
  transform: (doc, ret) => {
    ret.id = ret._id;
    delete ret._id;
  }
});

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;
